
export default {
    PAGESIZE: 5
}