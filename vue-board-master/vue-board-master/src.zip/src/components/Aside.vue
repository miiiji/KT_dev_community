<template>
    <div class="head_drop" style="position:relative; z-index: 100; right:0">
          <div class="dropdown-group-1">
            <p class="dropdown_list"><router-link style="color:#CDF1F4; font-size:24px; margin-top:100px" to="/outside">교육&세미나</router-link></p>
            <p class="dropdown_list"><router-link style="color:#CDF1F4; font-size:18px; margin-bottom:0px;" to="/outside">사외교육</router-link></p>
            <p class="dropdown_list"><router-link style="color:#CDF1F4; font-size:18px; margin-bottom:0px;" to="/inside">사내교육</router-link></p>
            <p class="dropdown_list"><router-link style="color:#CDF1F4; font-size:18px;" to="/request">교육요청</router-link></p>
          </div>
          <div class="dropdown-group-2">
            <p class="dropdown_list"><router-link style="color:#CDF1F4; font-size:24px;" to="/List">기술공유</router-link></p>

          </div>
        </div>
</template>
