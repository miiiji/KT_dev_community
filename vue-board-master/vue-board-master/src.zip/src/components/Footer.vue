<template>
    <div class="footer">
        <p>copyright (c) Miji Kim</p>
    </div>
</template>
<style>
.footer{border-top:1px solid #000;height:30px;padding:15px 0;text-align:Center;box-sizing:border-box;}
.footer p{font-size:13px;color:#000;line-height:50px;}
@media screen and (min-width:320px) and (max-width:1024px){
.footer{height:60px;}
.footer p{font-size:12px;line-height:30px;}
}
</style>

