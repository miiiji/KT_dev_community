import Vue from "vue"

var vm = new Vue({
    name :"EventBus"
});

export default vm;